# Esmeraldas Conecta

Proyecto web conectado a Supabase.

## Configuración
- Supabase URL: https://upnfkakdcxminzeckiga.supabase.co
- La clave usada en `app.js` es la **Publishable key** pública.
- Tabla: `public.businesses`

## Ejecutar
Abre `index.html` mediante un servidor local/hosting estático. No uses la `service_role` key en el navegador.

## Base de datos
La tabla `businesses` debe existir con las políticas de lectura e inserción creadas en Supabase SQL Editor.
